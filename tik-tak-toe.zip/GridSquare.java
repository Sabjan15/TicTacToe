//Keeps track of One Square
 public class GridSquare
 {
   
  public int state;
  public int position; 
 

  //Constructor - Set default value of the Square
  public GridSquare(int x){
 
  position = x; 
  state = -1; 
  }
  
  public char drawSpace() {
    if(state == 1) 
    {
      return 'X';
    }

     if(state == 0) 
     {
      return 'O';
     }
      return Integer.toString(position).charAt(0);
  }
  //Method to evaluate the game state  
   //format , if nothing else is true 
}



