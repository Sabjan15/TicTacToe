import java.util.Scanner;
public class TicTacToe
{

   int rows = 3;
   int cols = 3;
   int totalTurns = 0;
   int win = -1;  
   // char c = 'X';
  
   String xPiece = "X";
   String oPiece = "Y";

   enum GameState 
   {
     OVER, RUNNING
   }

  static GameState current = GameState.OVER;
  GridSquare[][] board;

//Sets up the initial board of the game
 public void setup()
 {
  board = new GridSquare[rows][cols];
  int position = 1;
  //write a nested for loop 
        for(int i = 0; i < rows; i++) 
      {
        for(int k = 0; k < cols; k++)
        {
          board[i][k] = new GridSquare(position);
          position++;
        }   
      }
      current = GameState.RUNNING;
      playGame(); 

  }

  //
  public void playGame()
  { 
    while(current == GameState.RUNNING){
  displayBoard();
  makeMove();
  }
  if(current == GameState.OVER) 
   {
     displayGameOver(); 
   }
  }
  
  public void displayBoard()
  { 
    //first row
      System.out.println("\n " + board[0][0].drawSpace() + " | " + board[0][1].drawSpace() + " | "  + board[0][2].drawSpace() );
      System.out.println(" __|__|__");

    //second row 
     System.out.println(" " + board[1][0].drawSpace() + " | " + board[1][1].drawSpace() + " | " + board[1][2].drawSpace() );
     System.out.println(" __|__|__");
    
    //third row
     System.out.println("  "+ board[2][0].drawSpace() + " | " + board[2][1].drawSpace() + " | " + board[2][2].drawSpace() ); 
      System.out.println("  |  |  ");

      System.out.println("\n");
      
  }
  public char getPlayer()
  {
    //totalTurns variable
   if(totalTurns % 2 == 0 ) {
    return 'X';
   }
   return 'O';
  }
  public void makeMove() 
  { 
    // Scanner Object
    Scanner reader = new Scanner(System.in);

   System.out.println ("choose a position");
   
      
      //First ask the player to choose a position
      int playerPos = reader.nextInt();
      
      //Find that position
      for(int i = 0; i < rows; i++ ) 
      {
       for(int k = 0; k < cols; k++ )
        {
          if(board[i][k].state == -1 && board[i][k].position == playerPos)
          {
            board[i][k].state = totalTurns % 2;
            totalTurns++;
            checkWin(i, k, board[i][k].state);
          }
        }
 
      }
      
      //Check if there's something already there
    
      //if not, put that player's symbol in

      //update totalTurns
  }
  public void displayGameOver() 
  {
    //display board
    displayBoard();

    //print out game over
    System.out.println("Game Over"); 
    
    //display winner based on if winner is 0 or 1
    if(win == 1)
    {
      System.out.println("X wins!");
    }
    else {
      System.out.println("O wins");
    }
    //check tie with totalTurns variable
    if (totalTurns == 9)
    {
      System.out.println("tie!");
    }
  }

  // Win Algorithm
 public void checkWin(int r, int c, int turn)
 {
   //after every turn we want to check if there is three in a row vertically, diagonally, and horizontally
    int row = 0;
    int col = 0;
    int diag = 0;
    int secDiag = 0;
    

    for(int x = 0; x < 3; x++)
    { 
      //check columns
      if (board[r][x].state == turn)
        {
          col++; 
        }
        //check row
      if(board[x][c].state == turn)
        {
          row++;
        }
    
  //check diagonal 1
    if (board [x][x].state == turn){
      diag++;
    }
    
    //check diagonal 2
      if (board[x][2-x].state == turn){
        secDiag++;
      }
    }
    
    //if else statement - check if 3
    if(row == 3 || col == 3 || diag == 3 || secDiag == 3) 
    {
       win = turn;
       System.out.println(win);
      if(win != -1)
      {
        current = GameState.OVER;
      }
    }

    //tie
    if(totalTurns == 9)
    {
      current = GameState.OVER;
    }
   //3 squares in same row 
   //3 squares in the same col 
   //3 squares in diagonal
   //3 squares in the second diagonal

 }
}