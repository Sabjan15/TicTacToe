
class Main {
  public static void main(String[] args) 
  {
    
    //Create new object of TicTacToe
    TicTacToe game = new TicTacToe();
    game.setup();
    //2d array a grid : 1d array is a list.

    // 1D Array   GridSquare[] name = new GridSquare
    
   // GridSquare[] board = new GridSquare[];

    //2D Array
    //GridSquare[][] board = new GridSquare[3][3];

   //int temp =  board[1][2];

    /*board[0][0] = 1;

    for(int i = 0; i < rows; i++) 
      {
        for(int k = 0; k < cols; k++)
        {
          board[i][k] = 21;
        }
      } */
    
    

  }
}